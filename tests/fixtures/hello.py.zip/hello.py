from __future__ import print_function


def handler(event, context):
    to_echo = event['to_echo']
    print("You asked me to say {}".format(to_echo))
    return True
